package com.test.nkbookshop.domain.po;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

public class User implements Serializable {

    //声明属性
    private Integer id;
    private String usn;
    private String pwd;
    private int age;
    private Date birthday;
    private double salary;
    private Timestamp regtime;

    //封装公有
    public Integer getId() {
        return id;
    }

    public String getUsn() {
        return usn;
    }

    public String getPwd() {
        return pwd;
    }

    public int getAge() {
        return age;
    }

    public Date getBirthday() {
        return birthday;
    }

    public double getSalary() {
        return salary;
    }

    public Timestamp getRegtime() {
        return regtime;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setUsn(String usn) {
        this.usn = usn;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setRegtime(Timestamp regtime) {
        this.regtime = regtime;
    }
    //生成构造方法
    public User(){}
    public User(Integer id, String usn, String pwd, int age, Date birthday, double salary, Timestamp regtime) {
        this.id = id;
        this.usn = usn;
        this.pwd = pwd;
        this.age = age;
        this.birthday = birthday;
        this.salary = salary;
        this.regtime = regtime;
    }

    public User(String usn, String pwd, int age, Date birthday, double salary, Timestamp regtime) {
        this.usn = usn;
        this.pwd = pwd;
        this.age = age;
        this.birthday = birthday;
        this.salary = salary;
        this.regtime = regtime;
    }


    //toString
    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", usn='" + usn + '\'' +
                ", pwd='" + pwd + '\'' +
                ", age=" + age +
                ", birthday=" + birthday +
                ", salary=" + salary +
                ", regtime=" + regtime +
                '}';
    }
}
