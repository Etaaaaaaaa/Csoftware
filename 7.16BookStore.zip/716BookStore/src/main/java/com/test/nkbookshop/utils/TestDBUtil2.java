package com.test.nkbookshop.utils;

public class TestDBUtil2 {
    public static void main(String[] args){
        System.out.println(DBUtils.driver);
        System.out.println(DBUtils.url);
    }
}
