package com.test.nkbookshop.dao.jbdcimpl;

import com.test.nkbookshop.dao.UserDao;
import com.test.nkbookshop.domain.po.User;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

public class TestUserDao {
    public static void main(String[] args) {
        // 0. 声明 dao 实例对象
        UserDao userDao = new UserDaoImpl();
        // 1. 查询测试
//        User user = userDao.findById(1);
//        System.out.println(user);
        //删除测试
        // userDao.delete(1);
        List<User> users = userDao.findAll();
        for (User u : users)
            System.out.println(u);
        // 2. 插入测试
//        Date birthday =new Date(System.currentTimeMillis());
//        Timestamp regtime = new Timestamp(System.currentTimeMillis());
//        User newUser = new User("lisi", "password",
//                21, birthday, 1.2, regtime);
//        int result = userDao.insert(newUser);
//        System.out.println(result);

    }
}
