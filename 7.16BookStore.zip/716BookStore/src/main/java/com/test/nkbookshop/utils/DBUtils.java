package com.test.nkbookshop.utils;

import java.io.IOException;
import java.util.Properties;

//generate file reader class
//read file dbconfig.properties -- key==value
//simply methods and variables
public class DBUtils {
    //declare private static properties
    //Instantiate class Properties

    private static Properties prop=new Properties();

    //declare static code block -- all properties are static variables
    //getClassLoader -- webProject locate configProperties
    static {
        try {
            prop.load(DBUtils.class.getClassLoader().getResourceAsStream("dbconfig.properties"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //declare public properties
    public static String driver= prop.getProperty("jbdc.driver");
    public static String url= prop.getProperty("jbdc.url");
    public static String user= prop.getProperty("jbdc.user");
    public static String password= prop.getProperty("jbdc.password");


}
