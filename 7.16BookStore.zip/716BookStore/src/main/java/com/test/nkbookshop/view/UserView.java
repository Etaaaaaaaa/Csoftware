package com.test.nkbookshop.view;

import com.test.nkbookshop.domain.po.User;
import com.test.nkbookshop.web.controller.UserController;

import javax.jws.soap.SOAPBinding;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class UserView {
    public static void login() {
        UserController userController = new UserController();
        //1- page : log in
        //simulate user input
        String usn = "yexiaoluo";
        String pwd = "password";
        User loginUser = new User();
        loginUser.setUsn(usn);
        loginUser.setPwd(pwd);
        userController.setUser(loginUser);
        String resultView = userController.login();
        System.out.println(resultView);
    }

    public static void register() {
        UserController userController = new UserController();
        String usn = "wangwu";
        String pwd = "password";
        int age = 22;
        Calendar calendar = Calendar.getInstance();
        calendar.set(2001, 1, 19);
        Date birthday = calendar.getTime();
        double salary = 1.3;
        Timestamp regtime = new Timestamp(System.currentTimeMillis());
        User registerUser = new User(usn, pwd, age, birthday, salary, regtime);
        userController.setUser(registerUser);
        String resultView = userController.register();
        System.out.println(resultView);

    }

    public static void showAllUsers() {
        List<User> users = new ArrayList<>();
        UserController userController = new UserController();
        users=userController.showAllUsers();
        System.out.println(users);


    }

    public static void main(String[] args) {
//       login();
//       register();
        showAllUsers();

    }
}
