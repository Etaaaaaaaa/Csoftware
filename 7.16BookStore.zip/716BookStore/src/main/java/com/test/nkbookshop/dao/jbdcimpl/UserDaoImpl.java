package com.test.nkbookshop.dao.jbdcimpl;

import com.test.nkbookshop.dao.UserDao;
import com.test.nkbookshop.domain.po.User;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl extends GenericBaseDao implements UserDao {
    @Override
    public User findById(Integer id) {
        User user = null;

        try {
            this.getConnection();
            String sql = "select * from users where id = ?";
            this.executeQuery(sql, id);
            if (rs != null && rs.next()) {
                // 将一行记录封装到一个实体类对象中
                user = new User(rs.getInt("id"), rs.getString("usn"),
                        rs.getString("pwd"), rs.getInt("age"),
                        rs.getDate("birthday"), rs.getDouble("salary"),
                        rs.getTimestamp("regtime"));
            }
            this.closeAll();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }

    @Override
    public List<User> findAll() {
        List<User> users = null;
        try {
            this.getConnection();
            String sql = "select * from users";
            this.executeQuery(sql);
            if (rs != null) {
                users = new ArrayList<>();
                while (rs.next()) {
                    User user = new User(rs.getInt("id"), rs.getString("usn"),
                            rs.getString("pwd"),rs.getInt("age"), rs.getDate("birthday"), rs.getDouble("salary"),
                            rs.getTimestamp("regtime"));
                    users.add(user);
                }

            }
            this.closeAll();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return users;
    }

    @Override
    public int insert(User user) {
        int res = -1;
        try {
            this.getConnection();
            String sql = "insert into users values(null,?,?,?,?,?,?)";
            this.executeUpdate(sql, user.getUsn(), user.getPwd(), user.getAge(), user.getBirthday(), user.getSalary(), user.getRegtime());
            res = result;
            this.closeAll();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return res;
    }

    @Override
    public int update(User user) {
        int res = -1;
        try {
            this.getConnection();
            String sql = "update users set usn = ?,pwd = ?,age=?,birthday=?,salary=?,regtime=? where id=?";
            this.executeUpdate(sql, user.getUsn(), user.getPwd(), user.getAge(), user.getBirthday(), user.getSalary(), user.getRegtime(), user.getId());
            res = result;
            this.closeAll();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return res;
    }

    @Override
    public int delete(Integer id) {
        int res = -1;
        try {
            this.getConnection();
            String sql = "delete from users where id=?";
            this.executeUpdate(sql, id);
            res = result;
            this.closeAll();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return res;
    }

    @Override
    public int delete(User user) {
        return this.delete(user.getId());
    }

    @Override
    public User findByName(String usn) {
        User user = null;

        try {
            this.getConnection();
            String sql = "select * from users where usn = ?";
            this.executeQuery(sql, usn);
            if (rs!=null && rs.next()){
                // 将一行记录封装到一个实体类对象中
                user = new User(rs.getInt("id"), rs.getString("usn"),
                        rs.getString("pwd"), rs.getInt("age"),
                        rs.getDate("birthday"), rs.getDouble("salary"),
                        rs.getTimestamp("regtime"));
            }
            this.closeAll();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }


    @Override
    public List<User> findBySQL(String sql, Object... Params) {
        return null;
    }
}
