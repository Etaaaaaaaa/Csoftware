package com.test.nkbookshop.web.controller;

import com.test.nkbookshop.domain.po.User;
import com.test.nkbookshop.service.UserService;
import com.test.nkbookshop.service.impl.UserServiceImpl;

import java.util.List;

public class UserController {
    private UserService userService=new UserServiceImpl();

    public UserService getUserService() {
        return userService;
    }

    public User getUser() {
        return user;
    }

    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    public void setUser(User user) {
        this.user = user;
    }

    private User user;
    public String login(){
        //get interface&view layer request parameters
       boolean res=userService.isValidate(user.getUsn(), user.getPwd());
        if(res)
            return "success";
        else
            return "usn or pwd is error";
    }
    public String register(){
        //get request
        //call next layer method(business logical layer)
        boolean res=userService.register(user);
        if(res)
            return "success";
        else
            return "fail";

    }
    public List<User> showAllUsers(){
        return userService.findAll();
    }
}
