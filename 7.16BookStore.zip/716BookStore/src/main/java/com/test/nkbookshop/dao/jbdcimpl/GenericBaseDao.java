package com.test.nkbookshop.dao.jbdcimpl;

import com.test.nkbookshop.utils.DBUtils;

import javax.print.DocFlavor;
import java.sql.*;

public class GenericBaseDao {
    //declare private static properties
    private static String driver= DBUtils.driver;
    private static String url=DBUtils.url;
    private static String user=DBUtils.user;
    private static String password=DBUtils.password;

    // static code -- driver registration one-time
    static {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    //commonality: get connection \ execute sql \ close
    //declare basic interface
    protected Connection conn;
    protected PreparedStatement pstmt;
    protected ResultSet rs;
    protected int result;

    //2-1. method -- get connection
    public void getConnection() throws SQLException {
        conn= DriverManager.getConnection(url,user,password);
    }
    //2-2. close connection
    public void closeAll() throws SQLException {
        //judge if empty & ON
        if(rs!=null&&!rs.isClosed())
            rs.close();
        if(pstmt!=null&&!pstmt.isClosed())
            pstmt.close();
        if(conn!=null&&!conn.isClosed())
            conn.close();
        if(result!=-1)
            result=-1;
    }
    //2-3. method -- add/delete/update
    //create sql statement container execute sql statement
    public void executeUpdate(String sql,Object... params) throws SQLException {
        //0 - create container
        pstmt = conn.prepareStatement(sql);
        //1 -
        if(params !=null){
            for(int i=0;i<params.length;i++)
            {
                pstmt.setObject(i+1,params[i]);
            }
        }
        //2 - execute sql
        result = pstmt.executeUpdate();
    }

    //2-4 method -- select
    public void executeQuery(String sql,Object... params) throws SQLException {
        //0 - create container
        pstmt = conn.prepareStatement(sql);
        //1 -
        if(params !=null){
            for(int i=0;i<params.length;i++)
            {
                pstmt.setObject(i+1,params[i]);
            }
        }
        //2 - execute sql put return result into resultset
        rs = pstmt.executeQuery();
    }

}
