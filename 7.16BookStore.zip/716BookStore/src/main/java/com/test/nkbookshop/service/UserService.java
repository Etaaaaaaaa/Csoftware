package com.test.nkbookshop.service;

import com.test.nkbookshop.domain.po.User;

import java.util.List;

//business logical layer interface
public interface UserService {
    //method -- relate to business logical
    boolean register(User user);
    boolean isValidate(String usn,String pwd);
    boolean remove(User user);
    boolean modify(User user);

    List<User> findAll();
}
